#ifndef __RESOURCE_virt_viewer_H__
#define __RESOURCE_virt_viewer_H__

#include <gio/gio.h>

extern GResource *virt_viewer_get_resource (void);
#endif
