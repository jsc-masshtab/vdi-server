//
// Created by Solomin on 13.06.19.
//

#ifndef VIRT_VIEWER_VEIL_VDI_MANAGER_H
#define VIRT_VIEWER_VEIL_VDI_MANAGER_H

#include <gtk/gtk.h>


gboolean vdi_manager_dialog(GtkWindow *main_window);

#endif //VIRT_VIEWER_VEIL_VDI_MANAGER_H
