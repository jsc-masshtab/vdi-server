#ifndef CRASHHANDLER_H
#define CRASHHANDLER_H


void installHandler(const char *logFileName);

#endif // CRASHHANDLER_H
